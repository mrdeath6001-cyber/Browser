package com.example.cleanbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class MainActivity extends Activity {
    static final String HOME = "https://duckduckgo.com/";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WC = ViewGroup.LayoutParams.WRAP_CONTENT;

    // Рекламные и трекерные домены (поддомены блокируются тоже)
    static final String[] AD_HOSTS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com", "criteo.com",
        "criteo.net", "pubmatic.com", "rubiconproject.com", "openx.net", "advertising.com", "adform.net",
        "amazon-adsystem.com", "moatads.com", "scorecardresearch.com", "popads.net", "popcash.net",
        "propellerads.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "clickadu.com",
        "adsterra.com", "onclickads.net", "mgid.com", "revcontent.com", "smartadserver.com",
        "casalemedia.com", "adcolony.com", "applovin.com", "ads.yahoo.com", "yandexadexchange.net",
        "an.yandex.ru", "hotjar.com", "quantserve.com", "bidswitch.net", "teads.tv", "zedo.com"
    };
    static final String HIDE_JS = "(function(){var s=document.createElement('style');"
        + "s.textContent='.adsbygoogle,ins.adsbygoogle,[id^=google_ads],iframe[src*=doubleclick],"
        + "iframe[src*=googlesyndication],[class*=ad-banner],[id*=ad-banner]{display:none!important}';"
        + "(document.head||document.documentElement).appendChild(s);})();";

    static class Tab {
        WebView wv;
        final LinkedHashSet<String> media = new LinkedHashSet<>();
    }

    final ArrayList<Tab> tabs = new ArrayList<>();
    int cur = -1;
    boolean desktop = false;
    FrameLayout content;
    EditText urlBar;
    ProgressBar bar;
    TextView tabBtn, dlBtn;
    SharedPreferences prefs;
    View customView;
    WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), dp(4), dp(4), dp(4));
        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setHint("Поиск или адрес");
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, a, e) -> {
            load(v.getText().toString());
            return true;
        });
        top.addView(urlBar, new LinearLayout.LayoutParams(0, WC, 1f));
        tabBtn = btn("1", v -> showTabs());
        top.addView(tabBtn);
        top.addView(btn("⋮", v -> showMenu()));
        root.addView(top, new LinearLayout.LayoutParams(MP, WC));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        root.addView(bar, new LinearLayout.LayoutParams(MP, dp(3)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(MP, 0, 1f));

        LinearLayout bot = new LinearLayout(this);
        View[] bs = {
            btn("◀", v -> tab().wv.goBack()),
            btn("▶", v -> tab().wv.goForward()),
            btn("⟳", v -> tab().wv.reload()),
            dlBtn = btn("⬇", v -> showMedia()),
            btn("★", v -> addBookmark())
        };
        for (View x : bs) bot.addView(x, new LinearLayout.LayoutParams(0, WC, 1f));
        root.addView(bot, new LinearLayout.LayoutParams(MP, WC));

        setContentView(root);
        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        Uri d = i.getData();
        if (d != null) newTab(d.toString());
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    TextView btn(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(dp(44));
        t.setPadding(dp(10), dp(10), dp(10), dp(10));
        t.setOnClickListener(l);
        return t;
    }

    Tab tab() {
        return cur >= 0 ? tabs.get(cur) : null;
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    static boolean isAd(String h) {
        if (h == null) return false;
        h = h.toLowerCase();
        if (h.startsWith("ads.") || h.startsWith("adserver.")) return true;
        for (String d : AD_HOSTS) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    void applyUa(WebSettings s) {
        s.setUserAgentString(desktop ? DESKTOP_UA : null);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
    }

    Tab newTab(String url) {
        final Tab t = new Tab();
        final WebView w = new WebView(this);
        t.wv = w;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        if (desktop) applyUa(s);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (isAd(u.getHost())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                String p = u.getPath();
                if (p != null && p.toLowerCase().matches(".*\\.(mp4|webm|mkv|mov|m4v|avi|mp3|m4a)")) {
                    synchronized (t.media) {
                        t.media.add(u.toString());
                    }
                    runOnUiThread(() -> updateUi());
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if ("http".equals(sc) || "https".equals(sc)) return false;
                if ("mailto".equals(sc) || "tel".equals(sc)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                    } catch (Exception e) {
                    }
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String u, Bitmap f) {
                synchronized (t.media) {
                    t.media.clear();
                }
                if (t == tab()) {
                    if (!urlBar.hasFocus()) urlBar.setText(u);
                    updateUi();
                }
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                v.evaluateJavascript(HIDE_JS, null);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t == tab()) {
                    bar.setProgress(p);
                    bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                if (!gesture) return false; // блокируем всплывающие окна без действия пользователя
                Tab n = newTab(null);
                ((WebView.WebViewTransport) msg.obj).setWebView(n.wv);
                msg.sendToTarget();
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                ((FrameLayout) getWindow().getDecorView()).addView(view);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }

            @Override
            public void onHideCustomView() {
                exitFullscreen();
            }
        });

        w.setDownloadListener((u, ua, cd, mime, len) -> download(u, ua, cd, mime, w.getUrl()));
        tabs.add(t);
        show(tabs.size() - 1);
        if (url != null) w.loadUrl(url);
        return t;
    }

    void exitFullscreen() {
        if (customView == null) return;
        ((FrameLayout) getWindow().getDecorView()).removeView(customView);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
    }

    void show(int i) {
        content.removeAllViews();
        cur = i;
        Tab t = tabs.get(i);
        content.addView(t.wv, new FrameLayout.LayoutParams(MP, MP));
        String u = t.wv.getUrl();
        urlBar.setText(u == null ? "" : u);
        bar.setVisibility(View.GONE);
        updateUi();
    }

    void closeTab() {
        Tab t = tabs.remove(cur);
        content.removeView(t.wv);
        t.wv.destroy();
        if (tabs.isEmpty()) newTab(HOME);
        else show(Math.min(cur, tabs.size() - 1));
    }

    void updateUi() {
        tabBtn.setText(String.valueOf(tabs.size()));
        Tab t = tab();
        int n = 0;
        if (t != null) {
            synchronized (t.media) {
                n = t.media.size();
            }
        }
        dlBtn.setText(n > 0 ? "⬇" + n : "⬇");
    }

    void load(String in) {
        String s = in.trim();
        if (s.isEmpty()) return;
        String u;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) u = s;
        else if (s.contains(".") && !s.contains(" ")) u = "https://" + s;
        else u = "https://duckduckgo.com/?q=" + Uri.encode(s);
        tab().wv.loadUrl(u);
        urlBar.clearFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void showTabs() {
        String[] names = new String[tabs.size()];
        for (int i = 0; i < names.length; i++) {
            String tt = tabs.get(i).wv.getTitle();
            names[i] = (i == cur ? "● " : "") + (tt == null || tt.isEmpty() ? "Новая вкладка" : tt);
        }
        new AlertDialog.Builder(this).setTitle("Вкладки")
            .setItems(names, (d, i) -> show(i))
            .setPositiveButton("Новая", (d, i) -> newTab(HOME))
            .setNegativeButton("Закрыть текущую", (d, i) -> closeTab())
            .show();
    }

    void showMenu() {
        String[] items = {"Новая вкладка", "Добавить в закладки", "Закладки", "Загрузки",
            desktop ? "Мобильная версия" : "Версия для ПК", "Очистить данные"};
        new AlertDialog.Builder(this).setItems(items, (d, i) -> {
            switch (i) {
                case 0: newTab(HOME); break;
                case 1: addBookmark(); break;
                case 2: showBookmarks(); break;
                case 3: startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); break;
                case 4:
                    desktop = !desktop;
                    for (Tab t : tabs) applyUa(t.wv.getSettings());
                    tab().wv.reload();
                    break;
                case 5:
                    CookieManager.getInstance().removeAllCookies(null);
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) {
                        t.wv.clearCache(true);
                        t.wv.clearHistory();
                    }
                    toast("Данные очищены");
                    break;
            }
        }).show();
    }

    void addBookmark() {
        Tab t = tab();
        String u = t.wv.getUrl();
        if (u == null) return;
        String ti = t.wv.getTitle();
        Set<String> s = new HashSet<>(prefs.getStringSet("bm", new HashSet<String>()));
        s.add((ti == null || ti.isEmpty() ? u : ti.replace("\n", " ")) + "\n" + u);
        prefs.edit().putStringSet("bm", s).apply();
        toast("Добавлено в закладки");
    }

    void showBookmarks() {
        final ArrayList<String> l = new ArrayList<>(prefs.getStringSet("bm", new HashSet<String>()));
        Collections.sort(l);
        if (l.isEmpty()) {
            toast("Закладок пока нет");
            return;
        }
        String[] n = new String[l.size()];
        for (int i = 0; i < n.length; i++) n[i] = l.get(i).split("\n")[0];
        new AlertDialog.Builder(this).setTitle("Закладки")
            .setItems(n, (d, i) -> tab().wv.loadUrl(l.get(i).split("\n")[1]))
            .setNeutralButton("Очистить все", (d, i) -> prefs.edit().remove("bm").apply())
            .show();
    }

    void showMedia() {
        final Tab t = tab();
        final ArrayList<String> l = new ArrayList<>();
        synchronized (t.media) {
            l.addAll(t.media);
        }
        if (l.isEmpty()) {
            toast("Файлов не найдено. Запустите воспроизведение видео на странице.");
            return;
        }
        String[] n = new String[l.size()];
        for (int i = 0; i < n.length; i++) n[i] = String.valueOf(Uri.parse(l.get(i)).getLastPathSegment());
        new AlertDialog.Builder(this).setTitle("Скачать файл")
            .setItems(n, (d, i) -> download(l.get(i), t.wv.getSettings().getUserAgentString(), null, null, t.wv.getUrl()))
            .show();
    }

    void download(String url, String ua, String cd, String mime, String referer) {
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request q = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) q.setMimeType(mime);
            if (ua != null) q.addRequestHeader("User-Agent", ua);
            if (referer != null) q.addRequestHeader("Referer", referer);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) q.addRequestHeader("Cookie", ck);
            q.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            q.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(q);
            toast("Загрузка: " + name);
        } catch (Exception e) {
            toast("Не удалось начать загрузку этого файла");
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            exitFullscreen();
            return;
        }
        Tab t = tab();
        if (t.wv.canGoBack()) t.wv.goBack();
        else if (tabs.size() > 1) closeTab();
        else super.onBackPressed();
    }
}
